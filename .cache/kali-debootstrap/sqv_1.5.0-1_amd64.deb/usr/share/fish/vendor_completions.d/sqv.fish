complete -c sqv -l output -d 'Write to FILE' -r -F
complete -c sqv -l signature-file -d 'Verify a detached signature file' -r -F
complete -c sqv -l keyring -d 'A keyring' -r -F
complete -c sqv -l not-after -d 'Consider signatures created after TIMESTAMP as invalid' -r
complete -c sqv -l not-before -d 'Consider signatures created before TIMESTAMP as invalid' -r
complete -c sqv -s n -l signatures -d 'The number of valid signatures to return success' -r
complete -c sqv -l time -d 'Set the reference time as an ISO 8601 formatted timestamp' -r
complete -c sqv -l policy-as-of -d 'Select the cryptographic policy as of the specified time' -r
complete -c sqv -l overwrite -d 'Overwrite the output file if it already exists'
complete -c sqv -l message -d 'Verify an inline signed message'
complete -c sqv -l cleartext -d 'Verify a cleartext-signed message'
complete -c sqv -s v -l verbose -d 'Be verbose'
complete -c sqv -s h -l help -d 'Print help (see more with \'--help\')'
complete -c sqv -s V -l version -d 'Print version'
